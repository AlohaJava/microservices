-- Adminer 4.7.7 PostgreSQL dump

DROP TABLE IF EXISTS "categories";
DROP SEQUENCE IF EXISTS categories_id_seq;
CREATE SEQUENCE categories_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1;

CREATE TABLE "public"."categories" (
    "id" integer DEFAULT nextval('categories_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL
) WITH (oids = false);


DROP TABLE IF EXISTS "email_messages";
DROP SEQUENCE IF EXISTS email_messages_id_seq;
CREATE SEQUENCE email_messages_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1;

CREATE TABLE "public"."email_messages" (
    "id" integer DEFAULT nextval('email_messages_id_seq') NOT NULL,
    "from_email" character varying(255) NOT NULL,
    "to_email" character varying(255) NOT NULL,
    "subject" character varying(255) NOT NULL,
    "message" character varying(255) NOT NULL,
    "file" character varying(255) NOT NULL
) WITH (oids = false);


DROP TABLE IF EXISTS "roles";
DROP SEQUENCE IF EXISTS roles_id_seq;
CREATE SEQUENCE roles_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1;

CREATE TABLE "public"."roles" (
    "id" integer DEFAULT nextval('roles_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL
) WITH (oids = false);


DROP TABLE IF EXISTS "topics";
DROP SEQUENCE IF EXISTS topics_id_seq;
CREATE SEQUENCE topics_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1;

CREATE TABLE "public"."topics" (
    "id" integer DEFAULT nextval('topics_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "created_by" integer NOT NULL,
    "telegram_chat_id" integer,
    "category_id" integer,
    "rating" integer NOT NULL,
    "description" text
) WITH (oids = false);

INSERT INTO "topics" ("id", "name", "created_by", "telegram_chat_id", "category_id", "rating", "description") VALUES
(4,	'тестовый топик',	1,	NULL,	1,	0,	'Тестовый топик описание'),
(2,	'Распределение налогов',	1,	NULL,	1,	0,	NULL),
(6,	'Расширение транспортной сети',	1,	NULL,	1,	10,	'Расширение транспортной сети'),
(3,	'Россети тестовая статья',	1,	NULL,	1,	0,	NULL),
(5,	'Россети',	1,	NULL,	1,	0,	'Тестовый топик описание'),
(1,	'тестовая статья',	1,	NULL,	1,	0,	NULL);

DROP TABLE IF EXISTS "user_to_topics";
CREATE TABLE "public"."user_to_topics" (
    "user_id" integer NOT NULL,
    "topic_id" integer NOT NULL
) WITH (oids = false);


DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1;

CREATE TABLE "public"."users" (
    "id" integer DEFAULT nextval('users_id_seq') NOT NULL,
    "username" character varying(255) NOT NULL,
    "password" character varying(255) NOT NULL,
    "role_id" integer NOT NULL,
    "telegram_username" character varying(255) NOT NULL,
    "full_name" character varying(255) NOT NULL
) WITH (oids = false);


-- 2020-11-28 19:52:12.085346+00
